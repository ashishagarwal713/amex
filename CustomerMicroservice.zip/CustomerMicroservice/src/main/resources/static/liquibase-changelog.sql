--liquibase formatted sql


--changeset create-customer-table
create table public.customer ( customerid bigint not null, customerName varchar(255), mobilenumber varchar(10), customerbillid bigint, primary key (customerid))