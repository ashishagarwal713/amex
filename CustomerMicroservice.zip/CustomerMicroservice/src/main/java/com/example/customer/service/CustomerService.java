package com.example.customer.service;

import java.util.List;

import com.example.customer.entity.Customer;

public interface CustomerService {


	public List<Customer> getCustomersWithDueBills();
	
	public Customer save(Customer customer);

}
