package com.example.customer.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.billing.service.BillingService;
import com.example.customer.entity.Customer;
import com.example.customer.repository.CustomerRepository;
import com.example.customer.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private BillingService billingService;

    public List<Customer> getCustomersWithDueBills() {
            List<Long> billIds = billingService.getBillIdsWithDueStatus();
            return customerRepository.findAll()
                    .stream()
                    .filter(customer -> billIds.contains(customer.getCustomerBillId()))
                    .collect(Collectors.toList());
    }

	@Override
	public Customer save(Customer customer) {
		return customerRepository.save(customer);
	}
}

