--liquibase formatted sql


--changeset create-billing-table
create table public.billing ( billid bigint not null, amount decimal, status varchar(5), primary key (billid))