package com.example.billing.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.billing.entity.Billing;
import com.example.billing.entity.Billing.Status;

public interface BillingRepository extends JpaRepository<Billing, Long> {
    List<Billing> findByStatus(Status due);
}
