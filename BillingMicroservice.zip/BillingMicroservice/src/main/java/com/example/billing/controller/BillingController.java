package com.example.billing.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.billing.entity.Billing;
import com.example.billing.service.BillingService;

@RestController
@RequestMapping("/billing")
public class BillingController {

    @Autowired
    private BillingService billingService;

    @GetMapping("/due")
    public List<Long> getBillIdsWithDueStatus() {
        return billingService.getBillIdsWithDueStatus();
    }
    
    @PostMapping("/add")
    public Billing addBilling(@RequestBody Billing billing) {
        return billingService.addBilling(billing);
    }
}


