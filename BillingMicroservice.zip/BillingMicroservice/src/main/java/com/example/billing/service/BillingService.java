package com.example.billing.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.billing.entity.Billing;
import com.example.billing.repository.BillingRepository;

@Service
public class BillingService {
    private final WebClient webClient;
    
    @Autowired
    private BillingRepository billingRepository;

    @Autowired
    public BillingService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("http://billing-service").build();
    }

    public List<Long> getBillIdsWithDueStatus() {
        return webClient.get()
                        .uri("/billings/due")
                        .retrieve()
                        .bodyToMono(new ParameterizedTypeReference<List<Long>>() {})
                        .block();
    }

	public Billing addBilling(Billing billing) {
		return billingRepository.save(billing);
	}
}

