package com.example.billing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillingMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillingMicroserviceApplication.class, args);
	}

}
