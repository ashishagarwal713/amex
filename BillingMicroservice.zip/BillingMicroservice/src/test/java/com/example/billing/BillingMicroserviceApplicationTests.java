package com.example.billing;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.billing.entity.Billing;
import com.example.billing.repository.BillingRepository;
import com.example.billing.service.BillingService;

@SpringBootTest
public class BillingMicroserviceApplicationTests {

    @Autowired
    private BillingService billingService;

    @Autowired
    private BillingRepository billingRepository;

    @Test
    public void testGetBillIdsWithDueStatus() {
        Billing bill = new Billing();
        bill.setAmount(100.0);
        bill.setStatus(Billing.Status.DUE);
        billingRepository.save(bill);

        List<Long> billIds = billingService.getBillIdsWithDueStatus();
        assertTrue(billIds.contains(bill.getBillId()));
    }
}

